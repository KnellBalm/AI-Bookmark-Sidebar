const SERVER = "http://192.168.101.224:18182";
const treeContainer = document.getElementById("tree");
const sendBtn = document.getElementById("sendBtn");
const logBox = document.getElementById("log");

let selected = new Set();

function renderNode(node, indent = 0) {
  const div = document.createElement("div");
  div.style.marginLeft = indent + "px";

  if (!node.url) {
    // 폴더
    const folder = document.createElement("div");
    folder.className = "folder";
    folder.textContent = "📁 " + (node.title || "(이름 없음)");
    div.appendChild(folder);

    const childrenBox = document.createElement("div");
    if (node.children) {
      node.children.forEach(c => childrenBox.appendChild(renderNode(c, indent + 16)));
    }
    div.appendChild(childrenBox);

  } else {
    // 실제 URL 북마크
    const wrap = document.createElement("div");
    wrap.className = "item";

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.addEventListener("change", () => {
      if (cb.checked) selected.add(node.url);
      else selected.delete(node.url);
    });

    const label = document.createElement("span");
    label.textContent = node.title || node.url;

    wrap.appendChild(cb);
    wrap.appendChild(label);
    div.appendChild(wrap);
  }

  return div;
}

// 북마크 트리 로드
chrome.bookmarks.getTree((nodes) => {
  nodes.forEach(n => treeContainer.appendChild(renderNode(n)));
});

// 전송 버튼
sendBtn.addEventListener("click", async () => {
  if (selected.size === 0) {
    logBox.textContent = "선택된 북마크가 없습니다.";
    return;
  }

  logBox.textContent = `총 ${selected.size}개 URL 전송 중...\n`;

  for (const url of selected) {
    try {
      const res = await fetch(`${SERVER}/ingest`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url })
      });

      if (!res.ok) {
        logBox.textContent += `❌ 실패: ${url} (${res.status})\n`;
      } else {
        const data = await res.json();
        logBox.textContent += `✅ 완료: ${url} (id=${data.id})\n`;
      }
    } catch (e) {
      logBox.textContent += `❌ 오류: ${url} → ${e}\n`;
    }
  }
});
